const axios = require( axios );
const fs = require( fs );
const path = require( path );

async function أمر_فيسبوك(سوك, معرف_الدردشة, رسالة) {
    try {
        const نص = رسالة.message?.conversation || رسالة.message?.extendedTextMessage?.text;
        const رابط = نص.split(   ).slice(1).join(   ).trim();
        
        if (!رابط) {
            return await سوك.sendMessage(معرف_الدردشة, { 
                text: "يرجى توفير رابط فيديو فيسبوك.\nمثال: .fb https://www.facebook.com/..."
            }, { quoted: رسالة });
        }

        // التحقق من صحة رابط فيسبوك
        if (!رابط.includes( facebook.com )) {
            return await سوك.sendMessage(معرف_الدردشة, { 
                text: "هذا ليس رابط فيسبوك."
            }, { quoted: رسالة });
        }

        // إرسال تفاعل التحميل
        await سوك.sendMessage(معرف_الدردشة, {
            react: { text:  🔄 , key: رسالة.key }
        });

        // تحويل روابط المشاركة/المختصرة إلى وجهتها النهائية أولاً
        let رابط_محلول = رابط;
        try {
            const استجابة = await axios.get(رابط, { timeout: 20000, maxRedirects: 10, headers: {  User-Agent :  Mozilla/5.0  } });
            const ممكن = استجابة?.request?.res?.responseUrl;
            if (ممكن && typeof ممكن ===  string ) {
                رابط_محلول = ممكن;
            }
        } catch {
            // تجاهل أخطاء التحليل؛ استخدام الرابط الأصلي
        }

        // استخدام واجهة برمجة تطبيقات Hanggts
        async function جلب_من_API(ر) {
            const رابط_API = `https://api.hanggts.xyz/download/facebook?url=${encodeURIComponent(ر)}`;
            
            try {
                const استجابة = await axios.get(رابط_API, {
                    timeout: 20000,
                    headers: {
                         accept :  */* ,
                         User-Agent :  Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 
                    },
                    maxRedirects: 5,
                    validateStatus: س => س >= 200 && س < 500
                });
                
                if (استجابة.data) {
                    // قبول الاستجابة إذا كانت الحالة صحيحة، أو إذا كان لدى الاستجابة حقول بيانات/نتيجة/رابط
                    if (استجابة.data.status === true || 
                        استجابة.data.result || 
                        استجابة.data.data || 
                        استجابة.data.url || 
                        استجابة.data.download || 
                        استجابة.data.video) {
                        return { استجابة, اسم_API:  Hanggts API  };
                    }
                }
            } catch (خطأ) {
                console.error(`فشل Hanggts API: ${خطأ.message}`);
            }
            throw new Error( فشل Hanggts API );
        }

        // حاول أولاً مع الرابط المحلول، ثم الرابط الأصلي كبديل
        let نتيجة_API;
        try {
            نتيجة_API = await جلب_من_API(رابط_محلول);
        } catch {
            نتيجة_API = await جلب_من_API(رابط);
        }

        const استجابة = نتيجة_API.استجابة;
        const اسم_API = نتيجة_API.اسم_API;
        const بيانات = استجابة.data;

        let فيديو_فيس = null;
        let عنوان = null;

        // التعامل مع تنسيق استجابة Hanggts API
        // حاول التحليل حتى لو لم تكن الحالة صريحة
        if (بيانات) {
            // جرب هياكل الاستجابة المحتملة المختلفة
            if (بيانات.result) {
                // تنسيق Hanggts API: بيانات.result.media.video_hd أو video_sd
                if (بيانات.result.media) {
                    // تفضل HD، ثم SD كبديل
                    فيديو_فيس = بيانات.result.media.video_hd || بيانات.result.media.video_sd;
                    عنوان = بيانات.result.info?.title || بيانات.result.title || بيانات.title || "فيديو فيسبوك";
                }
                // تحقق إذا كانت النتيجة كائن مع رابط
                else if (typeof بيانات.result ===  object  && بيانات.result.url) {
                    فيديو_فيس = بيانات.result.url;
                    عنوان = بيانات.result.title || بيانات.result.caption || بيانات.title || "فيديو فيسبوك";
                } 
                // تحقق إذا كانت النتيجة سلسلة (رابط مباشر)
                else if (typeof بيانات.result ===  string  && بيانات.result.startsWith( http )) {
                    فيديو_فيس = بيانات.result;
                    عنوان = بيانات.title || "فيديو فيسبوك";
                }
                // تحقق إذا كانت النتيجة لها خاصية تحميل أو فيديو
                else if (بيانات.result.download) {
                    فيديو_فيس = بيانات.result.download;
                    عنوان = بيانات.result.title || بيانات.title || "فيديو فيسبوك";
                } else if (بيانات.result.video) {
                    فيديو_فيس = بيانات.result.video;
                    عنوان = بيانات.result.title || بيانات.title || "فيديو فيسبوك";
                }
            }
            
            if (!فيديو_فيس && بيانات.data) {
                if (typeof بيانات.data ===  object  && بيانات.data.url) {
                    فيديو_فيس = بيانات.data.url;
                    عنوان = بيانات.data.title || بيانات.data.caption || بيانات.title || "فيديو فيسبوك";
                } else if (typeof بيانات.data ===  string  && بيانات.data.startsWith( http )) {
                    فيديو_فيس = بيانات.data;
                    عنوان = بيانات.title || "فيديو فيسبوك";
                } else if (Array.isArray(بيانات.data) && بيانات.data.length > 0) {
                    // تنسيق المصفوفة - ابحث عن أفضل جودة
                    const فيديو_HD = بيانات.data.find(عنصر => (عنصر.quality ===  HD  || عنصر.quality ===  high ) && (عنصر.format ===  mp4  || !عنصر.format));
                    const فيديو_SD = بيانات.data.find(عنصر => (عنصر.quality ===  SD  || عنصر.quality ===  low ) && (عنصر.format ===  mp4  || !عنصر.format));
                    فيديو_فيس = فيديو_HD?.url || فيديو_SD?.url || بيانات.data[0]?.url;
                    عنوان = فيديو_HD?.title || فيديو_SD?.title || بيانات.data[0]?.title || بيانات.title || "فيديو فيسبوك";
                } else if (بيانات.data.download) {
                    فيديو_فيس = بيانات.data.download;
                    عنوان = بيانات.data.title || بيانات.title || "فيديو فيسبوك";
                } else if (بيانات.data.video) {
                    فيديو_فيس = بيانات.data.video;
                    عنوان = بيانات.data.title || بيانات.title || "فيديو فيسبوك";
                }
            }
            
            if (!فيديو_فيس && بيانات.url) {
                فيديو_فيس = بيانات.url;
                عنوان = بيانات.title || بيانات.caption || "فيديو فيسبوك";
            }
            
            if (!فيديو_فيس && بيانات.download) {
                فيديو_فيس = بيانات.download;
                عنوان = بيانات.title || "فيديو فيسبوك";
            }
            
            if (!فيديو_فيس && بيانات.video) {
                if (typeof بيانات.video ===  string ) {
                    فيديو_فيس = بيانات.video;
                } else if (بيانات.video.url) {
                    فيديو_فيس = بيانات.video.url;
                }
                عنوان = بيانات.title || بيانات.video.title || "فيديو فيسبوك";
            }
        }

        if (!فيديو_فيس) {
            return await سوك.sendMessage(معرف_الدردشة, { 
                text:  ❌ فشل في الحصول على رابط الفيديو من فيسبوك.\n\nالأسباب المحتملة:\n• الفيديو خاص أو محذوف\n• الرابط غير صالح\n• الفيديو غير متاح للتحميل\n\nيرجى تجربة رابط فيديو فيسبوك مختلف. 
            }, { quoted: رسالة });
        }

        // حاول أولاً طريقة الرابط (أكثر موثوقية)
        try {
            const تسمية = عنوان ? `تم التحميل بواسطة الملك صقر\n\n📝 العنوان: ${عنوان}` : "تم التحميل بواسطة الملك صقر";
            
            await سوك.sendMessage(معرف_الدردشة, {
                video: { url: فيديو_فيس },
                mimetype: "video/mp4",
                caption: تسمية
            }, { quoted: رسالة });
            
            return;
        } catch (خطأ_الرابط) {
            console.error(`فشلت طريقة الرابط: ${خطأ_الرابط.message}`);
            
            // الرجوع إلى طريقة المخزن المؤقت
            try {
                // إنشاء مجلد مؤقت إذا لم يكن موجوداً
                const مجلد_مؤقت = path.join(process.cwd(),  tmp );
                if (!fs.existsSync(مجلد_مؤقت)) {
                    fs.mkdirSync(مجلد_مؤقت, { recursive: true });
                }

                // إنشاء مسار الملف المؤقت
                const ملف_مؤقت = path.join(مجلد_مؤقت, `فيس_${Date.now()}.mp4`);

                // تحميل الفيديو
                const استجابة_الفيديو = await axios({
                    method:  GET ,
                    url: فيديو_فيس,
                    responseType:  stream ,
                    timeout: 60000,
                    headers: {
                         User-Agent :  Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 ,
                         Accept :  video/mp4,video/*;q=0.9,*/*;q=0.8 ,
                         Accept-Language :  en-US,en;q=0.5 ,
                         Referer :  https://www.facebook.com/ 
                    }
                });

                const الكاتب = fs.createWriteStream(ملف_مؤقت);
                استجابة_الفيديو.data.pipe(الكاتب);

                await new Promise((حل, رفض) => {
                    الكاتب.on( finish , حل);
                    الكاتب.on( error , رفض);
                });

                // التحقق مما إذا تم تحميل الملف بنجاح
                if (!fs.existsSync(ملف_مؤقت) || fs.statSync(ملف_مؤقت).size === 0) {
                    throw new Error( فشل في تحميل الفيديو );
                }

                // إرسال الفيديو
                const تسمية = عنوان ? `تم التحميل بواسطة انور الحطامي\n\n📝 العنوان: ${عنوان}` : "تم التحميل بواسطة انور الحطامي";
                
                await سوك.sendMessage(معرف_الدردشة, {
                    video: { url: ملف_مؤقت },
                    mimetype: "video/mp4",
                    caption: تسمية
                }, { quoted: رسالة });

                // تنظيف الملف المؤقت
                try {
                    fs.unlinkSync(ملف_مؤقت);
                } catch (خطأ) {
                    console.error( خطأ في تنظيف الملف المؤقت: , خطأ);
                }
                return;
            } catch (خطأ_المخزن_المؤقت) {
                console.error(`فشلت طريقة المخزن المؤقت أيضاً: ${خطأ_المخزن_المؤقت.message}`);
                throw new Error( فشلت كلتا طريقتا الرابط والمخزن المؤقت );
            }
        }

    } catch (خطأ) {
        console.error( خطأ في أمر فيسبوك: , خطأ);
        await سوك.sendMessage(معرف_الدردشة, { 
            text: "حدث خطأ. قد تكون واجهة برمجة التطبيقات معطلة. الخطأ: " + خطأ.message
        }, { quoted: رسالة });
    }
}

module.exports = أمر_فيسبوك;