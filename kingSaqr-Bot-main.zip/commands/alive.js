const الإعدادات = require("../settings");
async function أمر_البوت_نشط(سوك, معرف_الدردشة, رسالة) {
    try {
        const الرسالة = `*🤖 بوت كنق صقر نشط!*\n\n` +
                       `*الإصدار:* ${الإعدادات.version}\n` +
                       `*الحالة:* متصل\n` +
                       `*الوضع:* عام\n\n` +
                       `*🌟 الميزات:*\n` +
                       `• إدارة المجموعات\n` +
                       `• حماية من الروابط\n` +
                       `• أوامر ترفيهية\n` +
                       `• والمزيد!\n\n` +
                       `اكتب *.menu* لقائمة الأوامر الكاملة`;

        await سوك.sendMessage(معرف_الدردشة, {
            text: الرسالة,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,

            }
        }, { quoted: رسالة });
    } catch (خطأ) {
        console.error( خطأ في أمر البوت نشط: , خطأ);
        await سوك.sendMessage(معرف_الدردشة, { text:  البوت نشط ويعمل!  }, { quoted: رسالة });
    }
}

module.exports = أمر_البوت_نشط;