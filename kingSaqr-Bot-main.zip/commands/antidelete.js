const fs = require( fs );
const path = require( path );
const { tmpdir } = require( os );
const { downloadContentFromMessage } = require( @whiskeysockets/baileys );
const { writeFile } = require( fs/promises );

const تخزين_الرسائل = new Map();
const مسار_الإعدادات = path.join(__dirname,  ../data/antidelete.json );
const مجلد_الوسائط_المؤقتة = path.join(__dirname,  ../tmp );

// التأكد من وجود المجلد المؤقت
if (!fs.existsSync(مجلد_الوسائط_المؤقتة)) {
    fs.mkdirSync(مجلد_الوسائط_المؤقتة, { recursive: true });
}

// دالة للحصول على حجم المجلد بالميغابايت
const الحصول_على_حجم_المجلد_بالميجابايت = (مسار_المجلد) => {
    try {
        const الملفات = fs.readdirSync(مسار_المجلد);
        let الحجم_الكلي = 0;

        for (const ملف of الملفات) {
            const مسار_الملف = path.join(مسار_المجلد, ملف);
            if (fs.statSync(مسار_الملف).isFile()) {
                الحجم_الكلي += fs.statSync(مسار_الملف).size;
            }
        }

        return الحجم_الكلي / (1024 * 1024); // تحويل البايت إلى ميغابايت
    } catch (خطأ) {
        console.error( خطأ في الحصول على حجم المجلد: , خطأ);
        return 0;
    }
};

// دالة لتنظيف المجلد المؤقت إذا تجاوز الحجم 10 ميغابايت
const تنظيف_المجلد_المؤقت_إذا_كان_كبيراً = () => {
    try {
        const الحجم_بالميجابايت = الحصول_على_حجم_المجلد_بالميجابايت(مجلد_الوسائط_المؤقتة);
        
        if (الحجم_بالميجابايت > 200) {
            const الملفات = fs.readdirSync(مجلد_الوسائط_المؤقتة);
            for (const ملف of الملفات) {
                const مسار_الملف = path.join(مجلد_الوسائط_المؤقتة, ملف);
                fs.unlinkSync(مسار_الملف);
            }
        }
    } catch (خطأ) {
        console.error( خطأ في تنظيف المجلد المؤقت: , خطأ);
    }
};

// بدء التحقق الدوري للتنظيف كل دقيقة
setInterval(تنظيف_المجلد_المؤقت_إذا_كان_كبيراً, 60 * 1000);

// تحميل الإعدادات
function تحميل_إعدادات_منع_الحذف() {
    try {
        if (!fs.existsSync(مسار_الإعدادات)) return { مفعّل: false };
        return JSON.parse(fs.readFileSync(مسار_الإعدادات));
    } catch {
        return { مفعّل: false };
    }
}

// حفظ الإعدادات
function حفظ_إعدادات_منع_الحذف(إعدادات) {
    try {
        fs.writeFileSync(مسار_الإعدادات, JSON.stringify(إعدادات, null, 2));
    } catch (خطأ) {
        console.error( خطأ في حفظ الإعدادات: , خطأ);
    }
}

const هو_المالك_أو_سودو = require( ../lib/isOwner );

// معالج الأمر
async function التعامل_مع_أمر_منع_الحذف(سوك, معرف_الدردشة, رسالة, مطابقة) {
    const معرف_المرسل = رسالة.key.participant || رسالة.key.remoteJid;
    const مالك = await هو_المالك_أو_سودو(معرف_المرسل, سوك, معرف_الدردشة);
    
    if (!رسالة.key.fromMe && !مالك) {
        return سوك.sendMessage(معرف_الدردشة, { text:  *فقط مالك البوت يمكنه استخدام هذا الأمر.*  }, { quoted: رسالة });
    }

    const الإعدادات = تحميل_إعدادات_منع_الحذف();

    if (!مطابقة) {
        return سوك.sendMessage(معرف_الدردشة, {
            text: `*إعدادات منع الحذف*\n\nالحالة الحالية: ${الإعدادات.مفعّل ?  ✅ مفعّل  :  ❌ غير مفعّل }\n\n*.antidelete on* - تفعيل\n*.antidelete off* - تعطيل`
        }, {quoted: رسالة});
    }

    if (مطابقة ===  on ) {
        الإعدادات.مفعّل = true;
    } else if (مطابقة ===  off ) {
        الإعدادات.مفعّل = false;
    } else {
        return سوك.sendMessage(معرف_الدردشة, { text:  *أمر غير صالح. استخدم .antidelete لرؤية طريقة الاستخدام.*  }, {quoted:رسالة});
    }

    حفظ_إعدادات_منع_الحذف(الإعدادات);
    return سوك.sendMessage(معرف_الدردشة, { text: `*تم ${مطابقة ===  on  ?  تفعيل  :  تعطيل } منع الحذف*` }, {quoted:رسالة});
}

// تخزين الرسائل الواردة (يتعامل أيضًا مع منع الرسائل ذات المشاهدة الواحدة عن طريق إعادة التوجيه فورًا)
async function تخزين_الرسالة(سوك, رسالة) {
    try {
        const الإعدادات = تحميل_إعدادات_منع_الحذف();
        if (!الإعدادات.مفعّل) return; // لا تخزن إذا كان منع الحذف معطل

        if (!رسالة.key?.id) return;

        const معرف_الرسالة = رسالة.key.id;
        let محتوى =   ;
        let نوع_الوسائط =   ;
        let مسار_الوسائط =   ;
        let مشاهدة_واحدة = false;

        const المرسل = رسالة.key.participant || رسالة.key.remoteJid;

        // اكتشاف المحتوى (بما في ذلك رسائل المشاهدة الواحدة)
        const حاوية_المشاهدة_الواحدة = رسالة.message?.viewOnceMessageV2?.message || رسالة.message?.viewOnceMessage?.message;
        if (حاوية_المشاهدة_الواحدة) {
            // فك محتوى المشاهدة الواحدة
            if (حاوية_المشاهدة_الواحدة.imageMessage) {
                نوع_الوسائط =  صورة ;
                محتوى = حاوية_المشاهدة_الواحدة.imageMessage.caption ||   ;
                const المخزن_المؤقت = await downloadContentFromMessage(حاوية_المشاهدة_الواحدة.imageMessage,  image );
                مسار_الوسائط = path.join(مجلد_الوسائط_المؤقتة, `${معرف_الرسالة}.jpg`);
                await writeFile(مسار_الوسائط, المخزن_المؤقت);
                مشاهدة_واحدة = true;
            } else if (حاوية_المشاهدة_الواحدة.videoMessage) {
                نوع_الوسائط =  فيديو ;
                محتوى = حاوية_المشاهدة_الواحدة.videoMessage.caption ||   ;
                const المخزن_المؤقت = await downloadContentFromMessage(حاوية_المشاهدة_الواحدة.videoMessage,  video );
                مسار_الوسائط = path.join(مجلد_الوسائط_المؤقتة, `${معرف_الرسالة}.mp4`);
                await writeFile(مسار_الوسائط, المخزن_المؤقت);
                مشاهدة_واحدة = true;
            }
        } else if (رسالة.message?.conversation) {
            محتوى = رسالة.message.conversation;
        } else if (رسالة.message?.extendedTextMessage?.text) {
            محتوى = رسالة.message.extendedTextMessage.text;
        } else if (رسالة.message?.imageMessage) {
            نوع_الوسائط =  صورة ;
            محتوى = رسالة.message.imageMessage.caption ||   ;
            const المخزن_المؤقت = await downloadContentFromMessage(رسالة.message.imageMessage,  image );
            مسار_الوسائط = path.join(مجلد_الوسائط_المؤقتة, `${معرف_الرسالة}.jpg`);
            await writeFile(مسار_الوسائط, المخزن_المؤقت);
        } else if (رسالة.message?.stickerMessage) {
            نوع_الوسائط =  ملصق ;
            const المخزن_المؤقت = await downloadContentFromMessage(رسالة.message.stickerMessage,  sticker );
            مسار_الوسائط = path.join(مجلد_الوسائط_المؤقتة, `${معرف_الرسالة}.webp`);
            await writeFile(مسار_الوسائط, المخزن_المؤقت);
        } else if (رسالة.message?.videoMessage) {
            نوع_الوسائط =  فيديو ;
            محتوى = رسالة.message.videoMessage.caption ||   ;
            const المخزن_المؤقت = await downloadContentFromMessage(رسالة.message.videoMessage,  video );
            مسار_الوسائط = path.join(مجلد_الوسائط_المؤقتة, `${معرف_الرسالة}.mp4`);
            await writeFile(مسار_الوسائط, المخزن_المؤقت);
        } else if (رسالة.message?.audioMessage) {
            نوع_الوسائط =  صوت ;
            const نوع_المحتوى = رسالة.message.audioMessage.mimetype ||   ;
            const الإمتداد = نوع_المحتوى.includes( mpeg ) ?  mp3  : (نوع_المحتوى.includes( ogg ) ?  ogg  :  mp3 );
            const المخزن_المؤقت = await downloadContentFromMessage(رسالة.message.audioMessage,  audio );
            مسار_الوسائط = path.join(مجلد_الوسائط_المؤقتة, `${معرف_الرسالة}.${الإمتداد}`);
            await writeFile(مسار_الوسائط, المخزن_المؤقت);
        }

        تخزين_الرسائل.set(معرف_الرسالة, {
            محتوى,
            نوع_الوسائط,
            مسار_الوسائط,
            المرسل,
            مجموعة: رسالة.key.remoteJid.endsWith( @g.us ) ? رسالة.key.remoteJid : null,
            الطابع_الزمني: new Date().toISOString()
        });

        // منع المشاهدة الواحدة: إعادة التوجيه فورًا إلى المالك إذا تم التقاطها
        if (مشاهدة_واحدة && نوع_الوسائط && fs.existsSync(مسار_الوسائط)) {
            try {
                const رقم_المالك = سوك.user.id.split( : )[0] +  @s.whatsapp.net ;
                const اسم_المرسل = المرسل.split( @ )[0];
                const خيارات_الوسائط = {
                    caption: `*محتوى مشاهدَة واحدة ${نوع_الوسائط}*
من: @${اسم_المرسل}`,
                    mentions: [المرسل]
                };
                if (نوع_الوسائط ===  صورة ) {
                    await سوك.sendMessage(رقم_المالك, { image: { url: مسار_الوسائط }, ...خيارات_الوسائط });
                } else if (نوع_الوسائط ===  فيديو ) {
                    await سوك.sendMessage(رقم_المالك, { video: { url: مسار_الوسائط }, ...خيارات_الوسائط });
                }
                // التنظيف الفوري لمحتوى المشاهدة الواحدة بعد إعادة التوجيه
                try { fs.unlinkSync(مسار_الوسائط); } catch {}
            } catch (خطأ) {
                // تجاهل
            }
        }

    } catch (خطأ) {
        console.error( خطأ في تخزين الرسالة: , خطأ);
    }
}

// التعامل مع حذف الرسائل
async function التعامل_مع_إلغاء_الرسالة(سوك, رسالة_الإلغاء) {
    try {
        const الإعدادات = تحميل_إعدادات_منع_الحذف();
        if (!الإعدادات.مفعّل) return;

        const معرف_الرسالة = رسالة_الإلغاء.message.protocolMessage.key.id;
        const محذوف_من_قبل = رسالة_الإلغاء.participant || رسالة_الإلغاء.key.participant || رسالة_الإلغاء.key.remoteJid;
        const رقم_المالك = سوك.user.id.split( : )[0] +  @s.whatsapp.net ;

        if (محذوف_من_قبل.includes(سوك.user.id) || محذوف_من_قبل === رقم_المالك) return;

        const الأصلية = تخزين_الرسائل.get(معرف_الرسالة);
        if (!الأصلية) return;

        const المرسل = الأصلية.المرسل;
        const اسم_المرسل = المرسل.split( @ )[0];
        const اسم_المجموعة = الأصلية.مجموعة ? (await سوك.groupMetadata(الأصلية.مجموعة)).subject :   ;

        const الوقت = new Date().toLocaleString( en-US , {
            timeZone:  Asia/Kolkata ,
            hour12: true, hour:  2-digit , minute:  2-digit , second:  2-digit ,
            day:  2-digit , month:  2-digit , year:  numeric 
        });

        let نص = `*🔰 تقرير منع الحذف 🔰*\n\n` +
            `*🗑️ حذف من قبل:* @${محذوف_من_قبل.split( @ )[0]}\n` +
            `*👤 المرسل:* @${اسم_المرسل}\n` +
            `*📱 الرقم:* ${المرسل}\n` +
            `*🕒 الوقت:* ${الوقت}\n`;

        if (اسم_المجموعة) نص += `*👥 المجموعة:* ${اسم_المجموعة}\n`;

        if (الأصلية.محتوى) {
            نص += `\n*💬 الرسالة المحذوفة:*\n${الأصلية.محتوى}`;
        }

        await سوك.sendMessage(رقم_المالك, {
            text: نص,
            mentions: [محذوف_من_قبل, المرسل]
        });

        // إرسال الوسائط
        if (الأصلية.نوع_الوسائط && fs.existsSync(الأصلية.مسار_الوسائط)) {
            const خيارات_الوسائط = {
                caption: `*${الأصلية.نوع_الوسائط} محذوف*\nمن: @${اسم_المرسل}`,
                mentions: [المرسل]
            };

            try {
                switch (الأصلية.نوع_الوسائط) {
                    case  صورة :
                        await سوك.sendMessage(رقم_المالك, {
                            image: { url: الأصلية.مسار_الوسائط },
                            ...خيارات_الوسائط
                        });
                        break;
                    case  ملصق :
                        await سوك.sendMessage(رقم_المالك, {
                            sticker: { url: الأصلية.مسار_الوسائط },
                            ...خيارات_الوسائط
                        });
                        break;
                    case  فيديو :
                        await سوك.sendMessage(رقم_المالك, {
                            video: { url: الأصلية.مسار_الوسائط },
                            ...خيارات_الوسائط
                        });
                        break;
                    case  صوت :
                        await سوك.sendMessage(رقم_المالك, {
                            audio: { url: الأصلية.مسار_الوسائط },
                            mimetype:  audio/mpeg ,
                            ptt: false,
                            ...خيارات_الوسائط
                        });
                        break;
                }
            } catch (خطأ) {
                await سوك.sendMessage(رقم_المالك, {
                    text: `⚠️ خطأ في إرسال الوسائط: ${خطأ.message}`
                });
            }

            // التنظيف
            try {
                fs.unlinkSync(الأصلية.مسار_الوسائط);
            } catch (خطأ) {
                console.error( خطأ في تنظيف الوسائط: , خطأ);
            }
        }

        تخزين_الرسائل.delete(معرف_الرسالة);

    } catch (خطأ) {
        console.error( خطأ في التعامل مع إلغاء الرسالة: , خطأ);
    }
}

module.exports = {
    التعامل_مع_أمر_منع_الحذف,
    التعامل_مع_إلغاء_الرسالة,
    تخزين_الرسالة
};